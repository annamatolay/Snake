Create the project and Activity using the instructions provided in the tutorial on www.androidgameprogramming.com/programming-a-snake-game
Drop the SnakeView.java file into the same folder as the auto-generated (during the step above)SnakeActivity.java file.
Copy the contents of the SnakeActivity file in this download and paste them into the SnakeActivity.java file already in your project. !!WARNING!! Don't overwrite the package declaration at the top of your file!
Copy and Paste the assets folder into the YOUR DRIVE:\YOUR FOLDER\Snake\app\src\main.

Enjoy!
The green robot�s second best friend